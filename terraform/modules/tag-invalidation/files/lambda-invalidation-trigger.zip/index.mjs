// =============================================================================
// Invalidation Trigger Lambda
// =============================================================================
// 触发: 由 Express API 或 Step Functions 调用
// 功能: 接收 tag 列表，查询 DynamoDB 获取关联 URL，调用 CloudFront 批量失效
// 运行时: Node.js 20.x (ESM)
// =============================================================================

import { DynamoDBClient, QueryCommand } from '@aws-sdk/client-dynamodb';
import {
  CloudFrontClient,
  CreateInvalidationCommand,
  ListInvalidationsCommand,
} from '@aws-sdk/client-cloudfront';

const TABLE_NAME = process.env.DYNAMODB_TABLE_NAME;
const DISTRIBUTION_ID = process.env.DISTRIBUTION_ID;
const BATCH_SIZE = parseInt(process.env.INVALIDATION_BATCH_SIZE || '3000', 10);

const dynamodb = new DynamoDBClient({});
const cloudfront = new CloudFrontClient({});

/**
 * 查询单个 tag 关联的所有 URL
 * DynamoDB 使用分页查询，确保获取全部结果
 */
async function getUrlsByTag(tag) {
  const urls = [];
  let lastEvaluatedKey = undefined;

  do {
    const params = {
      TableName: TABLE_NAME,
      KeyConditionExpression: 'tag = :tagValue',
      ExpressionAttributeValues: {
        ':tagValue': { S: tag },
      },
      ProjectionExpression: 'url, uri, querystring',
    };

    if (lastEvaluatedKey) {
      params.ExclusiveStartKey = lastEvaluatedKey;
    }

    const result = await dynamodb.send(new QueryCommand(params));

    if (result.Items) {
      for (const item of result.Items) {
        // url 字段存储完整 URL（含 querystring）
        const url = item.url?.S;
        if (url && !urls.includes(url)) {
          urls.push(url);
        }
      }
    }

    lastEvaluatedKey = result.LastEvaluatedKey;
  } while (lastEvaluatedKey);

  return urls;
}

/**
 * 将 URL 数组分成固定大小的批次
 * CloudFront CreateInvalidation API 每次最多 3000 路径
 */
function chunkArray(arr, size) {
  const chunks = [];
  for (let i = 0; i < arr.length; i += size) {
    chunks.push(arr.slice(i, i + size));
  }
  return chunks;
}

/**
 * 调用 CloudFront CreateInvalidation API
 */
async function createInvalidation(paths) {
  if (paths.length === 0) return null;

  const callerReference = 'tag-invalidation-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8);

  const command = new CreateInvalidationCommand({
    DistributionId: DISTRIBUTION_ID,
    InvalidationBatch: {
      Paths: {
        Quantity: paths.length,
        Items: paths,
      },
      CallerReference: callerReference,
    },
  });

  return cloudfront.send(command);
}

export const handler = async (event) => {
  console.log('Received event:', JSON.stringify(event));

  // 支持多种调用方式: Lambda Function URL / API Gateway / 直接调用
  let body;
  if (event.body) {
    // HTTP 调用（Lambda Function URL / API Gateway）
    body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
  } else {
    // 直接调用（SDK / Step Functions）
    body = event;
  }

  const { tags, tag } = body;
  // 支持单个 tag 或 tag 数组
  const tagList = tags || (tag ? [tag] : []);

  if (tagList.length === 0) {
    return {
      statusCode: 400,
      body: JSON.stringify({
        error: 'Missing required parameter: tag or tags',
        usage: '{ "tag": "product-1" } or { "tags": ["product-1", "category-hair"] }',
      }),
    };
  }

  console.log('Processing tags:', tagList);

  // 查询所有 tag 关联的 URL（去重）
  const allUrls = new Set();
  for (const t of tagList) {
    const urls = await getUrlsByTag(t);
    urls.forEach(u => allUrls.add(u));
  }

  const urlList = Array.from(allUrls);
  console.log('Found ' + urlList.length + ' unique URLs to invalidate');

  if (urlList.length === 0) {
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'No cached URLs found for the given tags',
        tags: tagList,
        invalidated_count: 0,
      }),
    };
  }

  // 分批失效（每批最多 BATCH_SIZE 条路径）
  const batches = chunkArray(urlList, BATCH_SIZE);
  const results = [];

  for (const batch of batches) {
    try {
      const result = await createInvalidation(batch);
      results.push({
        invalidation_id: result.Invalidation?.Id,
        paths_count: batch.length,
        status: result.Invalidation?.Status,
      });
      console.log('Created invalidation:', result.Invalidation?.Id, 'with', batch.length, 'paths');
    } catch (err) {
      console.error('Invalidation error:', err);
      results.push({
        error: err.message,
        paths_count: batch.length,
      });
    }
  }

  return {
    statusCode: 200,
    body: JSON.stringify({
      message: 'Tag-based invalidation completed',
      tags: tagList,
      total_urls: urlList.length,
      batches: results,
      invalidated_urls: urlList.slice(0, 20), // 返回前 20 条供参考
    }),
  };
};
