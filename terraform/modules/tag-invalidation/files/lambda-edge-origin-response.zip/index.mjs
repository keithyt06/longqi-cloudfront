// =============================================================================
// Lambda@Edge: Origin Response - Cache Tag 捕获
// =============================================================================
// 触发: CloudFront Origin Response（仅 Cache Miss 时执行）
// 功能: 解析源站响应中的 Cache-Tag header，将 tag → URL 映射写入 DynamoDB
// 运行时: Node.js 20.x (ESM)
// =============================================================================

import { DynamoDBClient, PutItemCommand } from '@aws-sdk/client-dynamodb';

// DynamoDB 配置
// Lambda@Edge 在边缘节点运行，显式指定 DynamoDB 所在区域
const DYNAMODB_REGION = 'ap-northeast-1';
const TABLE_NAME = 'unice-demo-cache-tags';
const TAG_HEADER = 'cache-tag';
const TAG_DELIMITER = ',';
const TAG_TTL_SECONDS = 86400;

const dynamodb = new DynamoDBClient({ region: DYNAMODB_REGION });

export const handler = async (event) => {
  const response = event.Records[0].cf.response;
  const request = event.Records[0].cf.request;

  // 检查响应中是否包含 Cache-Tag header
  const tagHeader = response.headers[TAG_HEADER];
  if (!tagHeader || !tagHeader[0] || !tagHeader[0].value) {
    return response;
  }

  const tagValue = tagHeader[0].value;
  const uri = request.uri;
  const querystring = request.querystring;
  // 完整 URL = URI + QueryString（作为缓存键的一部分）
  const fullUrl = querystring ? uri + '?' + querystring : uri;

  // 解析多个 tag（逗号分隔，去除空白）
  const tags = tagValue.split(TAG_DELIMITER).map(t => t.trim()).filter(t => t.length > 0);

  // 计算 TTL 过期时间（Unix 时间戳）
  const expireAt = TAG_TTL_SECONDS > 0
    ? Math.floor(Date.now() / 1000) + TAG_TTL_SECONDS
    : 0;

  // 并行写入所有 tag → URL 映射到 DynamoDB
  const writePromises = tags.map(tag => {
    const params = {
      TableName: TABLE_NAME,
      Item: {
        tag: { S: tag },
        url: { S: fullUrl },
        uri: { S: uri },
        querystring: { S: querystring || '' },
        updated_at: { S: new Date().toISOString() },
        distribution_id: { S: event.Records[0].cf.config.distributionId },
      },
    };

    // 仅在 TTL > 0 时添加 expire_at 属性
    if (expireAt > 0) {
      params.Item.expire_at = { N: String(expireAt) };
    }

    return dynamodb.send(new PutItemCommand(params));
  });

  try {
    await Promise.all(writePromises);
  } catch (err) {
    // Lambda@Edge 中写入失败不应阻塞响应
    // 错误会记录到 CloudWatch Logs（对应区域）
    console.error('DynamoDB write error:', err);
  }

  // 删除 Cache-Tag header，不暴露给客户端
  delete response.headers[TAG_HEADER];

  return response;
};
